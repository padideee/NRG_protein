int numNodes;
int *compsub = NULL;

void bk(vector<node>&, bool*&);
void Extend(int*, int, int, vector<node>&, bool*&, int);