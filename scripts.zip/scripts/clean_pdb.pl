#!/usr/bin/perl

use strict;

my $init = "UNDEF";
my $target = "UNDEF";

for my $i (0..@ARGV-1) {
	if ($ARGV[$i] eq "-i") {$init = $ARGV[$i+1];}
	if ($ARGV[$i] eq "-t") {$target = $ARGV[$i+1];}

}

unless (-e $init) {
	print "Please specify a PDB file to clean\n";
	exit;
}

if ($target eq "UNDEF") {
	print "Please specify a destination name for the cleaned PDB\n";
	exit;
}


clean($init,$target,"all");
my $random = int(rand(10000));
system "cp $target $random.pdb";
fix_insertion("$random.pdb","$target");
system "rm $random.pdb";






sub fix_insertion() {
	open IN, "$_[0]";
	open OUT, ">$_[1]";
	my @in = <IN>;
  close IN;
  
  # Get Resnumc
 	my %uni;
 	my %replace;
 	my %toadd;
  foreach my $l (@in) {
    	
  	if ($l =~ m/^ATOM.............(...).(.)\s*(\d+)(.)/) {
  		my $res = $1;
  		my $tc = $2;
  		my $num  = $3;
  		my $ins = $4;
  		if ($ins eq " ") {
			#	print "$res $tc $num $ins\n";
				my $new_num = sprintf("%4d",$num + $toadd{$tc});
				#print "$l";
				$l =~ s/^(ATOM..................)(\s*\d+)(.)/$1$new_num$3/;
				#print "$l";
			}
  		
  	}
  
  	 if ($l =~ m/^ATOM.......(.....).(.........)(.)/) {
    	my $tresnumc = "$2$3";
    	my $insert = $3;
    	if ($replace{$tresnumc} ne undef) {
    		$l =~ s/$tresnumc/$replace{$tresnumc}/;
    		print OUT "$l";
    		next;
    	}
    	
    	
    	
  	#	print "$tresnumc\n";
  		++$uni{$tresnumc};
  		if ($insert ne " ") {
  		#	print "$tresnumc\n";
  			my $short = $tresnumc;
  			$short =~ s/....(.*).$/$1/;
  			my $similar = 0;
				foreach my $k (keys %uni) {
					my $ks = $k;
					$ks =~ s/....(.*).$/$1/;
					if ($k eq $tresnumc) {next;}
					if ($ks eq $short) {
						++$similar;
						#print "	$k -> $ks et $short\n";
					}
					
				}
				if ($similar != 0) {
				#	print "$short\n";
					if ($short =~ m/(.)\s*(\d+)/) {
						my $ch = $1;
						
						my $num = $2;
						$toadd{$ch} += 1;
						my $new_num = sprintf("%4d",$num + $toadd{$ch});
						my $new_res = $tresnumc;
						$new_res =~ s/^(.....).*/$1$new_num /;
						#print "$tresnumc\n";
					#	print "$new_res\n";
						$replace{$tresnumc} = $new_res;
						$l =~ s/$tresnumc/$new_res/;
					}
				} else {
					my $new_res = $tresnumc;
					$new_res =~ s/^(.*).$/$1 /;
					$replace{$tresnumc} = $new_res;
					$l =~ s/$tresnumc/$new_res/;
				}
			#	print "Similar:$similar\n";
				#die;
  		}
  		
 	 }
 	 
 	 print OUT "$l";
	}
	

}







sub clean() {
 # Script perl qui enleve les HETATM et les acides aminée exotiques 1X

  open IN, "$_[0]"or die "Cannot open $_[0]";

  open OUT, ">$_[1]" or die "Cannot open $_[1]";
  my @in = <IN>;
  close IN;
	my $kchain = $_[2];
	print "I keep $kchain chain(s)\n";
	my %ctk; # Chain to keep
	unless($kchain eq "all") {
		foreach my $tc (split(/,/,$kchain)) {
			if ($tc eq undef) {next;}
			if (length($tc) != 1) {next;}
			$ctk{$tc} += 1;
		}
	}
	#die;
  my %chain;

  my $done = 0;
  my $long = 0;
  my $log = "";
  my @rem = (0,0,0,0);
  my %dupli;
  my @toprint = ();
  my %cresnumc;
  my %cresnumc_ca;
  
  #Negative number
  
  my %toadd;
  
  my %trans;
  
  foreach my $l (@in) {
		if ($l =~ m/^ATOM/) {++$long;}
		
		# Transforme SCH to cysteine
		if ($l =~ m/HETATM.....(....)..(SCH......)/) {
			my $atom = $1;
			my $trans_resnumc = $2;
			if ($trans{$trans_resnumc} eq undef) {
				print "Converting SCH to CYS -> $trans_resnumc\n";
				++$trans{$trans_resnumc};
			}
			if ($atom eq "  N " || $atom eq "  CA" || $atom eq "  CB" || $atom eq "  SG" || $atom eq "  C " || $atom eq "  O ") {
			
				
				$l =~ s/HETATM/ATOM  /;
				$l =~ s/SCH/CYS/;
				
				
			} else {next;}
			
			#die;
		}  
		# Transforme MSE to MET
		if ($l =~ m/HETATM.....(....)..(MSE......)/) {
			my $atom = $1;
			my $trans_resnumc = $2;
			if ($trans{$trans_resnumc} eq undef) {
				print "Converting MSE to MET -> $trans_resnumc\n";
				++$trans{$trans_resnumc};
			}
			$l =~ s/HETATM/ATOM  /;
			$l =~ s/MSE/MET/;
			$l =~ s/SE / SD/;
		}	
		
    if ($l =~ m/^HETATM/) {
    	++$long;
   #   print "$l";
      ++$rem[0];
      next;
    }
  
    
    if ($l =~ m/^ATOM.........H......../) {
    	++$rem[1];
      next;
    }
    if ($l =~ m/H\s*$/) {
      #print "$l";
      ++$rem[1];
      next;
    }
    
    # Add a chain
    if ($l =~ s/^(ATOM.................)( )/$1Z/) {
    }
  	my $nchain = " ";
   if ($l =~ m/^ATOM.......(.....).(.........)(.)/) {
    	my $tresnumc = $2;
    	my $insert = $3;
    	
    	if ($tresnumc =~ m/(...).(.)(.*)/) {
       	my $tchain = $2;
       	$nchain = $2;
       	my $num = $3;
       	$num =~ s/\s+//gi;
       	if ($num < 0) {
       		if ($toadd{$tchain} eq undef) {printf "Found negative residu numbering in chain $tchain, will add %d to all residue number\n",-$num;}
       		$toadd{$tchain} = -$num;
       	}
       	my $new_num = sprintf("%4d",$num + $toadd{$tchain});
       	$l =~ s/$tchain\s*$num/$tchain$new_num/;
       }
   
   } 
    my $duplik = "NA";
    my $resnumc = "NA";
   
    if ($l =~ m/^ATOM/) {
        if ($l =~ m/^ATOM.......(.....).(..........)/) {
            $duplik = "$1 $2";
            $resnumc = $2;
          
           ++$cresnumc{$resnumc};
         } else {print "$l\n";next;}
    }
    
    if ($dupli{$duplik} ne undef && $duplik ne "NA") {print "Alternate conformations $duplik\n";++$rem[2];next;} else {$dupli{$duplik} = 1;}
    $l =~ s/^(ATOM............)\S/$1 /;
   
    
    
   
    if ($l =~ m/^MODEL/) {
      #print "$l";
    }
     if ($done > 100 && $l =~ m/^MODEL\s+\d+/) {
    	$log .= "	I have multiple model, I kept only the first one !\n";
    	last;
    }
    unless($l =~ m/^ATOM/) {next;}
    
    # Regarder s'il s'agit d'un des 20 aa
    if ($l =~ m/^ATOM.............(...)/) {
    	my $taa = $1;
    	my $caa = mod_aa($taa);
    	if ($caa eq "X") {next;}
    }
    
    
    if ($l =~ m/^.....................(.)/ ) {
    	my $tc = $1;
    	$tc =~ s/\s+//;
      $chain{$tc} += 1;
     
      if ($kchain ne "all") {
      	if ($ctk{$tc} eq undef) {$rem[3] += 1;next;}
      }
    }
    ++$done;
   	push(@toprint,$l);
   

  }
  foreach my $l (@toprint) {
  	my $resnumc;
  	if ($l =~ m/^ATOM.......(.....).(..........)/) {
  		 $resnumc = $2;
  		 if ($cresnumc{$resnumc} < 4) {
  		 	print "$l";
  		 	print "Removed this residue because there is not enough atoms -> $resnumc = $cresnumc{$resnumc} atom(s)\n";
  		 	next;
  		 }
  	}
  	print OUT "$l";
  }
  close OUT;
  my $tot = 0;
  my @all_chain = keys  %chain;
  #$log .= "I have all those chain:@all_chain\n";
  foreach(keys  %chain) {
    ++$tot;
  }
  if ($tot != 1) {
   # print "$done/$long\n";
    foreach(keys  %chain) {
    	$log .= "	I have $chain{$_} atoms in chain $_\n";
    }

  }
  $log .= "	I had initially $long atoms, kept only $done, because I removed $rem[0] HETATM, $rem[1] Hydrogen Atoms, $rem[2] alternative conformations and $rem[3] chain atom were not kept\n";
  print "$log\n";
  #die;
	return($log)
}


sub mod_aa() {
  my $d = $_[0];

  if ($d eq "LYS") {return("K");}
  if ($d eq "ARG") {return("R");}
  if ($d eq "PHE") {return("F");}
  if ($d eq "LEU") {return("L");}
  if ($d eq "ILE") {return("I");}
  if ($d eq "TYR") {return("Y");}
  if ($d eq "GLU") {return("E");}
  if ($d eq "ASP") {return("D");}
  if ($d eq "GLY") {return("G");}
  if ($d eq "TRP") {return("W");}
  if ($d eq "ALA") {return("A");}
  if ($d eq "VAL") {return("V");}
  if ($d eq "THR") {return("T");}
  if ($d eq "HIS") {return("H");}
  if ($d eq "CYS") {return("C");}
  if ($d eq "SER") {return("S");}
  if ($d eq "ASN") {return("N");}
  if ($d eq "GLN") {return("Q");}
  if ($d eq "PRO") {return("P");}
  if ($d eq "MET") {return("M");}

  print "Cannot convert amino acid to one letter Code, check it -> $d\n";
  return("X");
}
